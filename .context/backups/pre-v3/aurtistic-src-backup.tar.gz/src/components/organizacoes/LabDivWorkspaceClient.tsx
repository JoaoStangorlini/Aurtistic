// Este programa é um software livre (Licença AGPLv3)
// ARQUIVO: src/components/organizacoes/LabDivWorkspaceClient.tsx
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import type { Task, TaskColumn, AgendaEvent } from '@/types';
import type {
  Organization,
  OrganizationMember,
  OrganizationSubteam,
  OrganizationMeeting,
  CognitiveCapacity,
} from '@/types/organizations';
import { TeamProgressPanel } from './TeamProgressPanel';
import { MemberCapacityQuickSelector } from './MemberCapacityQuickSelector';
import { OrganizationPlaybooksModal } from './OrganizationPlaybooksModal';
import { When2MeetSchedulerGrid } from './When2MeetSchedulerGrid';
import { LiveMeetingSplitWorkspace } from './LiveMeetingSplitWorkspace';
import { OrganizationGoalsPanel } from './OrganizationGoalsPanel';
import { OrganizationRequestsPanel } from './OrganizationRequestsPanel';
import { OrganizationScheduleAttendancePanel } from './OrganizationScheduleAttendancePanel';
import { OrganizationAdminModal } from './OrganizationAdminModal';
import { OrganizationMaterialSelector } from './OrganizationMaterialSelector';
import { OrgBenchStockPanel, OrgLiveStageModerationPanel } from './OrgBastidoresModules';
import { TasksView } from '@/components/dashboard/TasksView';
import {
  createOrganizationMeetingAction,
  getOrganizationDetailsAction,
  getOrganizationMeetingsAction,
} from '@/app/(dashboard)/organizacoes/actions';
import { saveTask } from '@/app/(dashboard)/actions';
import { JoinOrganizationModal } from './JoinOrganizationModal';
import { CreateOrganizationModal } from './CreateOrganizationModal';
import { OrganizationBrandProvider } from './OrganizationBrandProvider';

export interface LabDivWorkspaceClientProps {
  organization: Organization;
  subteams: OrganizationSubteam[];
  members: OrganizationMember[];
  initialTasks: Task[];
  initialMeetings: OrganizationMeeting[];
  columns: TaskColumn[];
  currentUserId: string;
  myMember?: OrganizationMember | null;
  quickFilters?: string[];
  quickSorts?: string[];
  advancedSettings?: Record<string, unknown>;
  userEvents?: AgendaEvent[];
  isDbMigrationPending?: boolean;
  userOrganizations?: Organization[];
  isEmbed?: boolean;
  ticket?: string;
}

export function LabDivWorkspaceClient({
  organization: initialOrg,
  subteams: initialSubteams,
  members: initialMembers,
  initialTasks,
  initialMeetings,
  columns,
  currentUserId,
  myMember,
  quickFilters = ['responsavel', 'dimensao'],
  quickSorts = ['status', 'prazo', 'prioridade', 'manual'],
  advancedSettings = {},
  userEvents = [],
  isDbMigrationPending = false,
  userOrganizations = [],
  isEmbed = false,
  ticket,
}: LabDivWorkspaceClientProps) {
  const router = useRouter();
  const [currentOrg, setCurrentOrg] = useState<Organization>(initialOrg);
  const [subteams, setSubteams] = useState<OrganizationSubteam[]>(initialSubteams);
  const [members, setMembers] = useState<OrganizationMember[]>(initialMembers);
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [meetings, setMeetings] = useState<OrganizationMeeting[]>(initialMeetings);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const organization = currentOrg;

  useEffect(() => {
    try {
      const saved = localStorage.getItem(`aurtistic_subteams_${organization.id}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setSubteams(parsed);
        }
      }
    } catch {}
  }, [organization.id]);

  const handleUpdateSubteams = (updated: OrganizationSubteam[]) => {
    setSubteams(updated);
    try {
      localStorage.setItem(`aurtistic_subteams_${organization.id}`, JSON.stringify(updated));
    } catch {}
  };

  const handleSwitchOrg = async (orgId: string) => {
    const selected = userOrganizations.find((o) => o.id === orgId);
    if (selected) {
      setCurrentOrg(selected);
      setSelectedMemberFilter(null);
      const [res, mRes] = await Promise.all([
        getOrganizationDetailsAction(orgId),
        getOrganizationMeetingsAction(orgId),
      ]);
      if (res.ok) {
        if (Array.isArray((res as any).subteams)) setSubteams((res as any).subteams);
        if (Array.isArray((res as any).members)) setMembers((res as any).members);
        if (Array.isArray((res as any).tasks)) setTasks((res as any).tasks);
      }
      if (mRes.ok && mRes.meetings) {
        setMeetings(mRes.meetings);
      }
      if (!isEmbed && selected.slug) {
        router.push(`/labdiv?org=${encodeURIComponent(selected.slug)}`);
      }
    }
  };
  const [showInlineVault, setShowInlineVault] = useState(true);
  const [isPlaybooksOpen, setIsPlaybooksOpen] = useState(false);
  const [activeMeetingForLive, setActiveMeetingForLive] = useState<OrganizationMeeting | null>(null);
  const [selectedMeetingForWhen2Meet, setSelectedMeetingForWhen2Meet] = useState<OrganizationMeeting | null>(null);
  const [expandedBastidoresSections, setExpandedBastidoresSections] = useState<string[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('aurtistic_expanded_bastidores_v2');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {}
    }
    return ['escalas_estoque'];
  });

  const toggleBastidoresSection = (sectionId: string) => {
    setExpandedBastidoresSections((prev) => {
      const next = prev.includes(sectionId) ? prev.filter((id) => id !== sectionId) : [...prev, sectionId];
      try {
        localStorage.setItem('aurtistic_expanded_bastidores_v2', JSON.stringify(next));
      } catch {}
      return next;
    });
  };
  const [subTabEscalas, setSubTabEscalas] = useState<'estoque' | 'escalas_when2meet'>('estoque');
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isCreatingMeeting, setIsCreatingMeeting] = useState(false);
  const [newMeetingTitle, setNewMeetingTitle] = useState('');
  const [selectedMemberFilter, setSelectedMemberFilter] = useState<string | null>(null);

  const isOrgAdmin =
    myMember?.org_role === 'admin' ||
    currentUserId === 'f2f1e6c9-a178-433f-9d87-37d6ce7ec94e';

  const handleCreateMeeting = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMeetingTitle.trim()) return;
    setIsCreatingMeeting(true);
    try {
      const res = await createOrganizationMeetingAction({
        organizationId: organization.id,
        title: newMeetingTitle.trim(),
        durationMinutes: 60,
      });
      if (res.ok && res.meeting) {
        setMeetings([res.meeting as OrganizationMeeting, ...meetings]);
        setNewMeetingTitle('');
      }
    } finally {
      setIsCreatingMeeting(false);
    }
  };

  const handleClaimTask = async (taskId: string) => {
    const target = tasks.find((t) => t.id === taskId);
    if (!target) return;
    const currentMember = members.find((m) => m.user_id === currentUserId) || myMember;
    const updated = {
      ...target,
      assignee_id: currentUserId,
      assigned_member_ids: currentMember ? [currentMember.id] : [],
      responsavel: currentMember ? currentMember.full_name : target.responsavel,
    };
    setTasks((prev) => prev.map((t) => (t.id === taskId ? updated : t)));
    try {
      await saveTask(updated);
    } catch {}
  };

  const handleAssignAllToMe = async () => {
    if (!myMember) return;
    const unassigned = tasks.filter(
      (t) =>
        (!t.assigned_member_ids || t.assigned_member_ids.length === 0) &&
        (!t.responsavel || t.responsavel.trim() === '' || t.responsavel === 'Sem Responsável')
    );
    if (unassigned.length === 0) return;

    for (const t of unassigned) {
      const updated: Task = {
        ...t,
        assignee_id: currentUserId,
        responsavel: myMember.full_name || 'João Stangorlini',
        assigned_member_ids: [myMember.id],
        organization_id: organization.id,
      };
      await saveTask(updated);
    }

    setTasks((prev) =>
      prev.map((t) => {
        const isUn =
          (!t.assigned_member_ids || t.assigned_member_ids.length === 0) &&
          (!t.responsavel || t.responsavel.trim() === '' || t.responsavel === 'Sem Responsável');
        if (isUn) {
          return {
            ...t,
            assignee_id: currentUserId,
            responsavel: myMember.full_name || 'João Stangorlini',
            assigned_member_ids: [myMember.id],
            organization_id: organization.id,
          };
        }
        return t;
      })
    );
  };

  const handleRelieveTask = async (taskId: string, targetMemberName: string) => {
    const target = tasks.find((t) => t.id === taskId);
    if (!target) return;
    const currentMember = members.find((m) => m.user_id === currentUserId) || myMember;
    const helperName = currentMember ? currentMember.full_name : 'colega';
    const updated = {
      ...target,
      assignee_id: currentUserId,
      assigned_member_ids: currentMember ? [currentMember.id] : [],
      responsavel: helperName,
    };
    setTasks((prev) => prev.map((t) => (t.id === taskId ? updated : t)));
    try {
      await saveTask(updated);
    } catch {}
  };

  return (
    <OrganizationBrandProvider orgSlug={currentOrg.slug} brandConfig={currentOrg.brand_config}>
      <div className="relative z-10 min-h-full flex flex-col p-4 md:p-8 space-y-6 text-fg">
      {isDbMigrationPending && (
        <div className="bg-amber-500/10 border border-amber-500/30 text-amber-200 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs shadow-md">
          <div className="flex items-center gap-2.5">
            <span className="material-symbols-outlined text-amber-400 text-[24px]">database</span>
            <div>
              <p className="font-bold text-amber-300">Migração de Banco de Dados Pendente no Supabase</p>
              <p className="text-amber-200/80 mt-0.5">
                Exibindo tarefas legadas vinculadas ao LabDiv (dimensão <code className="bg-black/40 px-1 py-0.5 rounded text-amber-300">HUB</code> / <code className="bg-black/40 px-1 py-0.5 rounded text-amber-300">LabDiv</code>). Para habilitar multi-organizações completas, execute o script <code className="bg-black/40 px-1.5 py-0.5 rounded font-mono text-amber-300">06_multi_organizations_v4_complete.sql</code> no SQL Editor do Supabase.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Faixa 1: Switch Macro [ Cofre | Organizações ] acima de tudo */}
      {!isEmbed && (
        <div className="flex justify-center shrink-0">
          <div className="inline-flex items-center p-1 bg-surface rounded-2xl border border-border-subtle shadow-md">
            <Link
              href={`/servidor?org=${encodeURIComponent(currentOrg.id)}`}
              prefetch={true}
              className="flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-bold text-fg-secondary hover:text-fg transition-colors"
              title={`Abrir Cofre de Arquivos de ${currentOrg.name}`}
            >
              <span className="material-symbols-outlined text-[16px]">folder_special</span>
              <span>Cofre</span>
            </Link>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-black bg-[#FFCC00] text-[#121212] shadow-sm">
              <span className="material-symbols-outlined text-[16px]">domain</span>
              <span>Organizações</span>
            </span>
          </div>
        </div>
      )}

      {/* Faixa 2: Card Fixo Idêntico — Logo + Switch de Conta (Organização/Pessoal) + Ação no canto direito */}
      <div data-tour="org-view-mode" className="relative shrink-0 flex flex-wrap items-center justify-between gap-4 bg-surface border border-border-subtle rounded-2xl p-4 shadow-lg z-20">
        <div className="flex items-center gap-3.5 min-w-0">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[var(--accent-primary)]/10 border border-[var(--accent-primary)]/30 overflow-hidden p-1.5 shadow-inner">
            {currentOrg.slug === 'labdiv' || (!currentOrg.slug && currentOrg.name?.toLowerCase().includes('labdiv')) ? (
              <img src="/labdiv-logo.png" alt="LabDiv" className="w-full h-full object-contain" />
            ) : currentOrg.slug === 'show-da-fisica' ? (
              <div className="w-full h-full flex flex-col items-center justify-center font-black text-center leading-none">
                <span className="text-[9px] text-[#ff1e1e]">SHOW</span>
                <span className="text-[8px] text-[#0066ff]">FÍSICA</span>
              </div>
            ) : currentOrg.slug === 'hs' ? (
              <div className="w-full h-full flex items-center justify-center font-mono font-bold text-[#00ff66] text-[11px]">
                &gt;_HS
              </div>
            ) : currentOrg.slug === 'profis' ? (
              <div className="w-full h-full flex flex-col items-center justify-center font-black text-center leading-none">
                <span className="text-[10px] text-[#F59E0B]">PRÓ</span>
                <span className="text-[8px] text-[#FFCC00]">FÍSICA</span>
              </div>
            ) : currentOrg.avatar_url ? (
              <img src={currentOrg.avatar_url} alt={currentOrg.name} className="w-full h-full object-contain" />
            ) : (
              <span className="text-lg font-black text-[var(--accent-primary)]">
                {currentOrg.name.slice(0, 2).toUpperCase()}
              </span>
            )}
          </div>
          <div>
            {isEmbed ? (
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-lg md:text-xl font-black font-bukra text-fg">
                  {currentOrg.name}
                </h2>
                <span className="text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full bg-[var(--accent-primary)]/15 border border-[var(--accent-primary)]/30 text-[var(--accent-primary)]">
                  Gestão Integrada
                </span>
              </div>
            ) : (
              <OrganizationMaterialSelector
                organizations={userOrganizations}
                selectedOrgId={currentOrg.id}
                onSelectOrg={(id) => id && handleSwitchOrg(id)}
                onCreateOrg={() => setIsCreateModalOpen(true)}
                onJoinWithCode={() => setIsAdminModalOpen(true)}
              />
            )}
          </div>
        </div>

        {/* Botão constante no canto direito na mesma altura e tom de Pedir Boost */}
        {!isEmbed && isOrgAdmin && (
          <button
            type="button"
            onClick={() => setIsAdminModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl border border-[var(--accent-primary)]/40 bg-[var(--accent-primary)]/10 px-3.5 py-2 text-xs font-bold text-[var(--accent-primary)] hover:bg-[var(--accent-primary)]/20 transition-colors cursor-pointer shadow-sm"
          >
            <span className="material-symbols-outlined text-[16px]">shield_person</span>
            <span>Credenciamento</span>
          </button>
        )}
      </div>

      <div className="space-y-6">
      {/* Cabeçalho Operacional Bastidores + Barra Única [01] a [06] */}
      {(() => {
        const isShow = currentOrg.slug === 'show-da-fisica';
        const isHs = currentOrg.slug === 'hs';
        const isProfis = currentOrg.slug === 'profis';
        const opsTag = isShow
          ? 'SF-OPS // BASTIDORES DO SHOW • Auditório Alessandro Volta • IFUSP'
          : isHs
            ? 'HS-OPS // HACKERSPACE • Oficina & Hardware Livre • IFUSP'
            : isProfis
              ? 'PF-OPS // PRÓ-FÍSICA (PROFIS) • Monitoria & Iniciação Científica • IFUSP'
              : 'LD-OPS // BASTIDORES LABDIV • Portal HUB LabDiv • IFUSP';

        const bastidoresTabs = [
          {
            id: 'escalas_estoque',
            num: '01',
            label: 'Reuniões & Escalas',
            icon: 'calendar_month',
            activeClass: isShow
              ? 'bg-[#002ffe] text-white shadow-[0_0_15px_#002ffe]'
              : isHs
                ? 'bg-[#00ff66] text-black shadow-[0_0_14px_rgba(0,255,102,0.45)]'
                : isProfis
                  ? 'bg-[#f59e0b] text-slate-950 shadow-[0_0_14px_rgba(245,158,11,0.4)]'
                  : 'bg-[#049fff] text-white shadow-[0_0_15px_rgba(4,159,255,0.45)]',
          },
          {
            id: 'tarefas_metas',
            num: '02',
            label: 'Tarefas & Metas',
            icon: 'checklist',
            activeClass: isShow
              ? 'bg-[#f60011] text-white shadow-[0_0_15px_#f60011]'
              : isHs
                ? 'bg-[#ffcc00] text-black shadow-[0_0_14px_rgba(255,204,0,0.4)]'
                : isProfis
                  ? 'bg-[#ffcc00] text-slate-950 shadow-[0_0_14px_rgba(255,204,0,0.4)]'
                  : 'bg-[#ffcc00] text-slate-950 shadow-[0_0_15px_rgba(255,204,0,0.45)]',
          },
          {
            id: 'moderacao_telao',
            num: '03',
            label: 'Telão & Ao Vivo',
            icon: 'sensors',
            activeClass: isShow
              ? 'bg-[#01f300] text-black shadow-[0_0_15px_#01f300]'
              : isHs
                ? 'bg-[#06b6d4] text-slate-950 shadow-[0_0_14px_rgba(6,182,212,0.4)]'
                : isProfis
                  ? 'bg-[#38bdf8] text-slate-950 shadow-[0_0_14px_rgba(56,189,248,0.4)]'
                  : 'bg-[#F14343] text-white shadow-[0_0_15px_rgba(241,67,67,0.4)]',
          },
          {
            id: 'pedidos_oficina',
            num: '04',
            label: 'Pedidos & Oficina',
            icon: 'inventory_2',
            activeClass: isShow
              ? 'bg-[#FFCC00] text-black shadow-[0_0_15px_#FFCC00]'
              : isHs
                ? 'bg-[#00ff66] text-black shadow-[0_0_14px_rgba(0,255,102,0.45)]'
                : isProfis
                  ? 'bg-[#f97316] text-white shadow-[0_0_14px_rgba(249,115,22,0.4)]'
                  : 'bg-[#0F4780] text-white shadow-[0_0_15px_rgba(15,71,128,0.45)]',
          },
          {
            id: 'acervo_cofre',
            num: '05',
            label: 'Acervo & Cofre',
            icon: 'folder_special',
            activeClass: isShow
              ? 'bg-[#002ffe] text-white shadow-[0_0_15px_#002ffe]'
              : isHs
                ? 'bg-[#ffcc00] text-black shadow-[0_0_14px_rgba(255,204,0,0.4)]'
                : isProfis
                  ? 'bg-[#f59e0b] text-slate-950 shadow-[0_0_14px_rgba(255,204,0,0.4)]'
                  : 'bg-[#1F9FCF] text-white shadow-[0_0_15px_rgba(31,159,207,0.4)]',
          },
          {
            id: 'equipe_apoio',
            num: '06',
            label: 'Equipe & Apoio',
            icon: 'diversity_3',
            activeClass: isShow
              ? 'bg-[#01f300] text-black shadow-[0_0_15px_#01f300]'
              : isHs
                ? 'bg-[#06b6d4] text-slate-950 shadow-[0_0_14px_rgba(6,182,212,0.4)]'
                : isProfis
                  ? 'bg-[#ffcc00] text-slate-950 shadow-[0_0_14px_rgba(255,204,0,0.4)]'
                  : 'bg-[#ffcc00] text-slate-950 shadow-[0_0_15px_rgba(255,204,0,0.45)]',
          },
        ] as const;

        return (
          <div className="space-y-4">
            <div className={`p-4 border ${isShow || isHs ? 'neon-border-green bg-black rounded-none' : 'org-card rounded-2xl border-border-subtle bg-surface/90 backdrop-blur-xl'} flex flex-wrap items-center justify-between gap-3`}>
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[var(--accent-primary)] block">
                  ● {opsTag}
                </span>
                <h2 className="text-xl sm:text-2xl font-black uppercase tracking-wider mt-1">
                  {isShow ? (
                    <>
                      <span className="neon-text-red">BASTIDORES</span> ·{' '}
                      <span className="neon-text-blue">GESTÃO</span> ·{' '}
                      <span className="neon-text-green">OPERAÇÃO</span>
                    </>
                  ) : (
                    <span>BASTIDORES · GESTÃO · OPERAÇÃO</span>
                  )}
                </h2>
              </div>
              <div className="flex flex-wrap items-center gap-2.5">
                <MemberCapacityQuickSelector
                  organizationId={currentOrg.id}
                  initialCapacity={myMember?.cognitive_capacity || 'normal'}
                  initialNote={myMember?.capacity_note || ''}
                />
                <span className={`px-3 py-1 text-[11px] font-mono font-bold uppercase border ${isShow || isHs ? 'neon-border-green text-[#01f300] rounded-none bg-black' : 'rounded-xl border-emerald-500/40 text-emerald-400 bg-emerald-500/10'}`}>
                  BANCADA OPERACIONAL ATIVA
                </span>
              </div>
            </div>

            {/* Botões Expansíveis das Divisões [01] a [06] */}
            <div className="flex flex-wrap items-center gap-2 pb-1">
              {bastidoresTabs.map((tab) => {
                const isExpanded = expandedBastidoresSections.includes(tab.id);
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => toggleBastidoresSection(tab.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-mono font-bold uppercase transition-all shrink-0 cursor-pointer border ${
                      isShow || isHs ? 'rounded-none' : 'rounded-xl'
                    } ${
                      isExpanded
                        ? `${tab.activeClass} border-transparent`
                        : 'bg-surface border-border-subtle text-fg-muted hover:text-fg hover:border-border-strong'
                    }`}
                    title={isExpanded ? `Recolher ${tab.label}` : `Expandir ${tab.label}`}
                  >
                    <span className="opacity-75 text-[10px]">[{tab.num}]</span>
                    <span className="material-symbols-outlined text-[15px]">{tab.icon}</span>
                    <span>{tab.label}</span>
                    <span className="material-symbols-outlined text-[16px] ml-0.5">
                      {isExpanded ? 'expand_less' : 'expand_more'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        );
      })()}

      {/* Conteúdo Unificado da Aba Operacional Selecionada */}
      {expandedBastidoresSections.includes('escalas_estoque') && (
        <div className={`p-4 md:p-6 border space-y-6 ${currentOrg.slug === 'show-da-fisica' ? 'neon-border-blue bg-black rounded-none' : 'org-card rounded-2xl border-border-subtle bg-surface'}`}>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border-subtle pb-4">
            <div>
              <h3 className="text-lg font-black uppercase text-fg">Escalas, Reuniões & Estoque de Bancada</h3>
              <p className="text-xs text-fg-muted">
                Status em tempo real dos aparatos, escalas de plantão e agendador When2Meet.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSubTabEscalas('estoque')}
                className={`px-3 py-1.5 text-xs font-mono font-bold uppercase cursor-pointer border ${
                  currentOrg.slug === 'show-da-fisica' || currentOrg.slug === 'hs' ? 'rounded-none' : 'rounded-lg'
                } ${
                  subTabEscalas === 'estoque'
                    ? 'bg-[var(--accent-primary)] text-slate-950 border-transparent'
                    : 'border-border-subtle text-fg-muted hover:text-fg'
                }`}
              >
                Estoque & Manutenção
              </button>
              <button
                type="button"
                onClick={() => setSubTabEscalas('escalas_when2meet')}
                className={`px-3 py-1.5 text-xs font-mono font-bold uppercase cursor-pointer border ${
                  currentOrg.slug === 'show-da-fisica' || currentOrg.slug === 'hs' ? 'rounded-none' : 'rounded-lg'
                } ${
                  subTabEscalas === 'escalas_when2meet'
                    ? 'bg-[var(--accent-primary)] text-slate-950 border-transparent'
                    : 'border-border-subtle text-fg-muted hover:text-fg'
                }`}
              >
                Escalas & When2Meet ({meetings.length})
              </button>
            </div>
          </div>

          {subTabEscalas === 'estoque' ? (
            <OrgBenchStockPanel key={currentOrg.slug} orgSlug={currentOrg.slug} />
          ) : (
            <div className="space-y-6">
              <OrganizationScheduleAttendancePanel
                key={currentOrg.slug}
                organization={currentOrg}
                subteams={subteams}
                members={members}
                currentUserId={currentUserId}
                currentUserName={myMember?.full_name || 'Membro do Laboratório'}
                isAdmin={isOrgAdmin}
              />

              <div data-tour="org-meetings-section" className="border-t border-border-subtle pt-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[20px] text-[var(--accent-primary)]">calendar_month</span>
                    <h4 className="text-base font-bold text-white">Reuniões da Equipe & When2Meet</h4>
                  </div>
                  <form onSubmit={handleCreateMeeting} className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Título da reunião..."
                      value={newMeetingTitle}
                      onChange={(e) => setNewMeetingTitle(e.target.value)}
                      className="rounded-lg border border-border-subtle bg-app text-fg px-3 py-1.5 text-xs placeholder-slate-500 focus:border-[var(--accent-primary)] focus:outline-none"
                    />
                    <button
                      type="submit"
                      disabled={isCreatingMeeting || !newMeetingTitle.trim()}
                      className="flex items-center gap-1 rounded-lg bg-[var(--accent-primary)] px-3 py-1.5 text-xs font-bold text-slate-950 hover:opacity-90 transition-opacity disabled:opacity-50 cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[16px]">add</span>
                      Agendar
                    </button>
                  </form>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {meetings.map((m) => (
                    <div
                      key={m.id}
                      className="flex flex-col justify-between rounded-xl border border-border-subtle bg-app text-fg p-4 transition-colors hover:border-border-strong"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className="text-xs font-bold text-white truncate">{m.title}</span>
                          <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] text-slate-400 font-mono">
                            {m.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mb-3">
                          {m.scheduled_at ? new Date(m.scheduled_at).toLocaleString('pt-BR') : 'Data a definir'} • {m.duration_minutes || 60} min
                        </p>
                      </div>

                      <div className="flex items-center gap-2 pt-2 border-t border-border-subtle">
                        <button
                          type="button"
                          onClick={() => setActiveMeetingForLive(m)}
                          className="flex-1 flex items-center justify-center gap-1 rounded-lg bg-[var(--accent-primary)]/15 border border-[var(--accent-primary)]/30 py-1.5 text-xs font-semibold text-[var(--accent-primary)] hover:bg-[var(--accent-primary)]/25 transition-colors cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[14px]">mic</span>
                          Abrir Ao Vivo
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setSelectedMeetingForWhen2Meet(
                              selectedMeetingForWhen2Meet?.id === m.id ? null : m
                            )
                          }
                          className={`rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                            selectedMeetingForWhen2Meet?.id === m.id
                              ? 'bg-[#FFCC00]/20 border-[#FFCC00] text-[#FFCC00]'
                              : 'border-border-subtle bg-surface text-fg-muted hover:text-fg hover:bg-surface-hover'
                          }`}
                        >
                          Horários
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {selectedMeetingForWhen2Meet && (
                  <div className="pt-4 border-t border-border-subtle">
                    <div className="mb-3 flex items-center justify-between">
                      <span className="text-xs font-bold text-[var(--accent-primary)]">
                        Definindo melhor horário para: {selectedMeetingForWhen2Meet.title}
                      </span>
                      <button
                        type="button"
                        onClick={() => setSelectedMeetingForWhen2Meet(null)}
                        className="text-xs text-slate-500 hover:text-slate-300"
                      >
                        Fechar Grade
                      </button>
                    </div>
                    <When2MeetSchedulerGrid
                      meetingId={selectedMeetingForWhen2Meet.id}
                      currentUserId={currentUserId}
                      userEvents={userEvents}
                    />
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {expandedBastidoresSections.includes('tarefas_metas') && (
        <div className="space-y-6">
          <OrganizationGoalsPanel key={`goals-${currentOrg.slug}`} organization={currentOrg} subteams={subteams} tasks={tasks} />
          <TasksView
            key={`tasks-${currentOrg.slug}`}
            initialTasks={tasks}
            initialColumns={columns}
            userId={currentUserId}
            initialQuickFilters={quickFilters}
            initialQuickSorts={quickSorts}
            advancedSettings={advancedSettings}
            showUnassignedBanner={true}
          />
        </div>
      )}

      {expandedBastidoresSections.includes('moderacao_telao') && (
        <OrgLiveStageModerationPanel key={`live-${currentOrg.slug}`} orgSlug={currentOrg.slug} />
      )}

      {expandedBastidoresSections.includes('pedidos_oficina') && (
        <OrganizationRequestsPanel
          key={`req-${currentOrg.slug}`}
          organization={currentOrg}
          subteams={subteams}
          currentUserId={currentUserId}
          currentUserName={myMember?.full_name || 'Membro do Laboratório'}
          isAdmin={isOrgAdmin}
        />
      )}

      {expandedBastidoresSections.includes('acervo_cofre') && (
        <div className="space-y-4">
          <div className={`p-5 border space-y-4 ${currentOrg.slug === 'show-da-fisica' || currentOrg.slug === 'hs' ? 'neon-border-blue bg-black rounded-none' : 'org-card rounded-2xl border-border-subtle bg-surface'}`}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-lg font-black uppercase text-fg">Acervo Técnico, Playbooks & Cofre da Organização</h3>
                <p className="text-xs text-fg-muted">
                  POPs de segurança, roteiros técnicos e acesso integrado ao Cofre de Mídia / Galeria de Fotos de {currentOrg.name}.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPlaybooksOpen(true)}
                  className="flex items-center gap-1.5 rounded-xl border border-indigo-500/40 bg-indigo-500/15 px-3.5 py-2 text-xs font-bold text-indigo-300 hover:bg-indigo-500/25 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">menu_book</span>
                  Abrir Playbooks / POPs
                </button>
                <button
                  type="button"
                  onClick={() => setShowInlineVault((prev) => !prev)}
                  className="flex items-center gap-1.5 rounded-xl border border-amber-500/40 bg-amber-500/15 px-3.5 py-2 text-xs font-bold text-amber-300 hover:bg-amber-500/25 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">
                    {showInlineVault ? 'unfold_less' : 'unfold_more'}
                  </span>
                  {showInlineVault ? 'Recolher Cofre Embutido' : 'Expandir Cofre Embutido'}
                </button>
                <Link
                  href={`/servidor?org=${encodeURIComponent(currentOrg.id)}`}
                  className="flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-3.5 py-2 text-xs font-bold text-slate-950 hover:opacity-90"
                >
                  <span className="material-symbols-outlined text-[16px]">open_in_new</span>
                  Tela Cheia
                </Link>
              </div>
            </div>
          </div>

          {showInlineVault && (
            <div className="rounded-2xl border border-border-subtle overflow-hidden bg-[#07090e] shadow-xl">
              <iframe
                key={`inline-vault-${currentOrg.id}`}
                src={`/servidor?org=${encodeURIComponent(currentOrg.id)}&embed=1&inline=1${ticket ? `&ticket=${encodeURIComponent(ticket)}` : ''}`}
                className="w-full h-[680px] border-0 bg-[#07090e]"
                title={`Cofre Compartilhado — ${currentOrg.name}`}
              />
            </div>
          )}
        </div>
      )}

      {expandedBastidoresSections.includes('equipe_apoio') && (
        <div className="space-y-4">
          <TeamProgressPanel
            key={`team-${currentOrg.slug}`}
            organization={currentOrg}
            subteams={subteams}
            members={members}
            tasks={tasks}
            currentUserId={currentUserId}
            onSelectMemberFilter={setSelectedMemberFilter}
            selectedMemberId={selectedMemberFilter}
            onClaimTask={handleClaimTask}
            onRelieveTask={handleRelieveTask}
            onAssignAllToMe={handleAssignAllToMe}
          />
        </div>
      )}

      {/* Modal Administrativo de Governança, Atribuições e Perfis */}
      <OrganizationAdminModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        organization={organization}
        subteams={subteams}
        members={members}
        tasks={tasks}
        currentUserId={currentUserId}
        onTasksUpdated={(updatedTasks) => setTasks(updatedTasks)}
        onSubteamsUpdated={handleUpdateSubteams}
      />

      {/* Modal de Playbooks da Organização */}
      <OrganizationPlaybooksModal
        isOpen={isPlaybooksOpen}
        onClose={() => setIsPlaybooksOpen(false)}
        organizationId={organization.id}
        subteams={subteams}
      />

      {/* Workspace de Reunião Ao Vivo (Tela Dividida + Transcrição Híbrida) */}
      {activeMeetingForLive && (
        <LiveMeetingSplitWorkspace
          isOpen={Boolean(activeMeetingForLive)}
          onClose={() => setActiveMeetingForLive(null)}
          meeting={activeMeetingForLive}
          isOrgAdmin={isOrgAdmin}
          onMeetingFinished={() => {
            setActiveMeetingForLive(null);
          }}
        />
      )}

      {/* Modais de Entrar / Criar Organização */}
      <JoinOrganizationModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
        onJoinedSuccess={async (orgId) => {
          handleSwitchOrg(orgId);
        }}
      />

      <CreateOrganizationModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onCreatedSuccess={async (orgId) => {
          handleSwitchOrg(orgId);
        }}
      />
      </div>
      </div>
    </OrganizationBrandProvider>
  );
}
