// Este programa é um software livre (Licença AGPLv3)
export interface TaskColumnOption {
  value: string;
  label: string;
  color?: string;
  id?: string;
}

export interface TaskColumn {
  id: string;
  key: string;
  name: string;
  type: 'select' | 'text' | 'date' | 'checkbox';
  options: TaskColumnOption[];
  is_native: boolean;
  order_num: number;
}

export interface Task {
  is_personal?: boolean;
  organization_id?: string | null;
  subteam_id?: string | null;
  assigned_subteam_ids?: string[];
  assignee_id?: string | null;
  goal_id?: string | null;
  assigned_member_ids?: string[];
  id: string;
  created_at: string;
  nome: string;
  status: string;
  prioridade: string | null;
  categoria: string | null;
  responsavel: string | null;
  inicio: string | null;
  prazo: string | null;
  descricao: string | null;
  frequencia: string | null;
  dimensao: string | null;
  concluida_em: string | null;
  user_id: string;
  ordem_manual?: number;
  is_favorite?: boolean;
  parent_id?: string | null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  custom_fields?: Record<string, any>;
}

export interface HorarioSemanal {
  inicio: string; // formato "HH:mm"
  fim: string;    // formato "HH:mm"
}

export interface AgendaEvent {
  id: string;
  user_id: string;
  nome: string;
  descricao: string | null;
  status?: string | null;
  data_inicio: string | null; // formato "YYYY-MM-DD"
  data_fim: string | null;    // formato "YYYY-MM-DD"
  horarios_semanais: Record<string, HorarioSemanal> | null; // ex: { "Segunda": { "inicio": "19:00", "fim": "21:00" } }
  frequencia: string | null;
  dimensao: string | null;
  is_labdiv: boolean;
  is_favorite?: boolean;
  created_at: string;
}

export * from './storage';
export * from './portfolio';
export * from './organizations';

